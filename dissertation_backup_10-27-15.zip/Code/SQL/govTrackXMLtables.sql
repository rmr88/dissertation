CREATE DATABASE govTrack

--DROP TABLE govTrack..bills
CREATE TABLE govTrack..bills (
	fileName VARCHAR(100),
	congress INT,
	bills XML)

--DROP TABLE govTrack..rolls
CREATE TABLE govTrack..rolls (
	fileName VARCHAR(100),
	congress INT,
	rolls XML)

use master
go
sp_configure 'show advanced options', 1
reconfigure with override
go
sp_configure 'xp_cmdshell', 1
reconfigure with override

Exec govTrack..[usp_uploadfiles]
@databasename ='govTrack',
@schemaname ='dbo',
@tablename ='rolls',
@FileNameColumn ='fileName',
@CongressColumn = 'congress',
@blobcolumn = 'rolls',
@congress = '113',
@path = 'c:\Users\Robbie\Documents\dissertation\Data\GovTrack\113\rolls\',
@filetype ='*.xml',
@printorexec ='exec'

select top 500 * from govTrack..rolls