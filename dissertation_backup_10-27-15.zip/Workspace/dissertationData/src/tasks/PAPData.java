package tasks;

public class PAPData
{
	public static void main(String args[])
	{
		
	}
}
