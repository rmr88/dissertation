package utilities;

public class Cosponsor extends JSONWrapper
{
	public String district;
	public String name;
	public String sponsored_at;
	public String state;
	public String thomas_id;
	public String title;
	public String withdrawn_at;
}
