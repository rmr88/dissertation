package utilities;

public abstract class JSONWrapper { }
